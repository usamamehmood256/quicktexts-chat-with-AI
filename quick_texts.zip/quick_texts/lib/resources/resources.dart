
import 'package:quick_texts/resources/text_style.dart';

import 'colors.dart';
import 'decorations.dart';
import 'dummy_text.dart';
import 'images.dart';
class R {
  static AppColors colors = AppColors();
  static AppImages images = AppImages();
  static AppDummyData dummyData = AppDummyData();
  static AppTextStyle textStyle = AppTextStyle();
  static AppDecorations decorations = AppDecorations();
}
