class AppImages {
  String splashLogo = "splashLogo.png";
  String logo = "logo.png";
  String landing1 = "landing1.png";
  String landing2 = "landing2.png";
  String landing3 = "landing3.png";
  String newMessage = "newMessage.png";
  String savedMessages = "savedMessages.png";
  String deleteAccount = "deleteAccount.png";
  String sendIcon = "sendIcon.png";
  String copyIcon = "copyIcon.png";
  String shareIcon = "shareIcon.png";
  String downloadIcon = "downloadIcon.png";
  String google = "google.png";
}
