class AppDummyData{

  var mediumText ="Lorem ipsum dolor sit amet, consectetur adipisc ing elit, sed do eius mod tempor incidid unt ut la bore et dolore magna aliqua";
   var shortText ="Lorem ipsum dolor sit ad minim amet, elit, sed cons ectetur adipiscsaing eli.";
   var bulletText ="Lorem ipsum dolor sit ad minim amet.";
   var longText ="Lorem ipsum dolor sit ad minim amet, elit,consectetur adipiscsaing elit, sed do eiusmod.tempor sed to doincididunt ut labore et dolore.Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.";
   var longerText ="Lorem ipsum dolor sit ad minim amet, elit, sed consectetur adipiscsaing elit, sed do eiusmod.tempor sed to doincididunt ut labore et dolore.Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum doloreeu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum, Lorem ipsum dolor sit ad minim amet, elit, sed consectetur adipiscsaing elit, sed do eiusmod.tempor sed to doincididunt ut labore et dolore.Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum";


}