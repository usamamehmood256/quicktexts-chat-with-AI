import 'package:get/get_navigation/src/routes/get_route.dart';



import '../screens/auth/forgot_password_page.dart';
import '../screens/auth/login_page.dart';
import '../screens/auth/sign_up_page.dart';
import '../screens/dashboard/dashboard_view.dart';
import '../screens/dashboard/settings_pages/about_us_view.dart';
import '../screens/dashboard/settings_pages/change_password_view.dart';
import '../screens/dashboard/settings_pages/privacy_policy_view.dart';
import '../screens/dashboard/settings_pages/profile/edit_profile_view.dart';
import '../screens/dashboard/settings_pages/profile/my_profile_view.dart';
import '../screens/dashboard/settings_pages/settings_view.dart';
import '../screens/dashboard/settings_pages/subscription_page.dart';
import '../screens/dashboard/settings_pages/terms_conditions_view.dart';
import '../screens/onboarding/landing_pages.dart';
import '../screens/splash/splash_page.dart';
import 'app_routes.dart';

abstract class AppPages {
  static List<GetPage> pages = [
     GetPage(name: Routes.splash, page: () => const SplashView()),
     GetPage(name: Routes.landingPage, page: () => const LandingPage()),
     GetPage(name: Routes.loginView, page: () =>  LoginView()),
     GetPage(name: Routes.signupView, page: () =>  SignupView()),
     GetPage(name: Routes.forgotPassword, page: () =>  ForgotPassword()),
     GetPage(name: Routes.dashboardView, page: () =>  DashboardView()),
     GetPage(name: Routes.settingsView, page: () =>  SettingsView()),
     GetPage(name: Routes.myProfileView, page: () =>  MyProfileView()),
     GetPage(name: Routes.editProfileVIew, page: () =>  EditProfileVIew()),
     GetPage(name: Routes.changePassword, page: () =>  ChangePassword()),
     GetPage(name: Routes.privacyPolicyView, page: () =>  PrivacyPolicyView()),
     GetPage(name: Routes.termsConditionsView, page: () =>  TermsConditionsView()),
     GetPage(name: Routes.subscriptionPageView, page: () =>  SubscriptionPageView()),
     GetPage(name: Routes.aboutUsView, page: () =>  AboutUsView()),

  ];
}
