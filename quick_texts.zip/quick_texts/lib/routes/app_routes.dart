class Routes{


static const splash="/";
  static const landingPage="/landingPage";
  static const loginView="/loginView";
  static const signupView="/signupView";
  static const dashboardView="/dashboardView";
  static const forgotPassword="/forgotPassword";
  static const settingsView="/settingsView";
  static const myProfileView="/myProfileView";
  static const editProfileVIew="/editProfileVIew";
  static const changePassword="/changePassword";
  static const privacyPolicyView="/privacyPolicyView";
  static const termsConditionsView="/termsConditionsView";
  static const subscriptionPageView="/subscriptionPageView";
  static const aboutUsView="/aboutUsView";











}