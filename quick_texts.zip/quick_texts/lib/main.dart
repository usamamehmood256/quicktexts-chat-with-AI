import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:get/get_navigation/src/root/get_material_app.dart';

import 'package:provider/provider.dart';
import 'package:quick_texts/routes/app_pages.dart';
import 'package:quick_texts/routes/app_routes.dart';
import 'package:quick_texts/screens/auth/provider/auth_provider.dart';
import 'package:quick_texts/widgets/app_theme.dart';
import 'package:responsive_framework/responsive_wrapper.dart';
import 'package:responsive_framework/utils/scroll_behavior.dart';

import 'firebase_options.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(MultiProvider(providers: [
    ChangeNotifierProvider(create: (_) => AuthProvider()),
  ], child: const MyApp()));
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      // home: ,
      debugShowCheckedModeBanner: false,
      // darkTheme: ThemeData.dark(),
      getPages: AppPages.pages,
      initialRoute: Routes.splash,
      title: "FireTexts",
      theme: myTheme,
      // ThemeData(
      //   // * Create your own palette, because black is not a material color.
      //   primarySwatch: const MaterialColor(
      //     0xFF03A9F4,
      //     <int, Color>{
      //       50: Color(0xff288E68),
      //       100: Color(0xff288E68),
      //       200: Color(0xff288E68),
      //       300: Color(0xff288E68),
      //       400: Color(0xff288E68),
      //       500: Color(0xff288E68),
      //       600: Color(0xff288E68),
      //       700: Color(0xff288E68),
      //       800: Color(0xff288E68),
      //       900: Color(0xff288E68),
      //     },
      //   ),
      //   scaffoldBackgroundColor: R.colors.bgColor,
      // ),
      builder: (context, widget) {
        return ResponsiveWrapper.builder(
          BouncingScrollWrapper.builder(context, widget!),
          maxWidth: 1200,
          minWidth: 320,
          defaultName: MOBILE,
          defaultScale: true,
          breakpoints: [
            const ResponsiveBreakpoint.resize(320,
                name: MOBILE, scaleFactor: 1.0),
            const ResponsiveBreakpoint.resize(480, name: MOBILE),
            const ResponsiveBreakpoint.resize(600, name: MOBILE),
            const ResponsiveBreakpoint.autoScale(850, name: TABLET),
            const ResponsiveBreakpoint.resize(1080, name: DESKTOP),
          ],
        );
      },
    );
  }
}
