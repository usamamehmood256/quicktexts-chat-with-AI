import 'package:flutter/material.dart';
import 'package:get/get.dart';


import '../base/resizer/fetch_pixels.dart';
import '../base/widget_utils.dart';
import '../resources/resources.dart';
import '../widgets/my_button.dart';


class OrderStatusDialog extends StatefulWidget {
  final String image;
  final String text;
  final Function onTap;
  const OrderStatusDialog({Key? key,required this.image,required this.text,required this.onTap,}) : super(key: key);

  @override
  State<OrderStatusDialog> createState() => _OrderStatusDialogState();
}

class _OrderStatusDialogState extends State<OrderStatusDialog>
    with SingleTickerProviderStateMixin {
  late AnimationController controller;
  late Animation<double> scaleAnimation;

  @override
  void initState() {
    super.initState();

    controller = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 500));
    scaleAnimation =
        CurvedAnimation(parent: controller, curve: Curves.easeInOut);

    controller.addListener(() {
      setState(() {});
    });

    controller.forward();
  }

  var horSpace = FetchPixels.getPixelHeight(20);

  @override
  Widget build(BuildContext context) {
    FetchPixels(context);
    return ScaleTransition(
      scale: scaleAnimation,
      child: Dialog(
        insetPadding:
            EdgeInsets.symmetric(horizontal: FetchPixels.getPixelWidth(20)),
        shape: RoundedRectangleBorder(
            borderRadius:
                BorderRadius.circular(FetchPixels.getPixelHeight(22))),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          mainAxisSize: MainAxisSize.min,
          children: [
            getVerSpace(FetchPixels.getPixelHeight(30)),
            getAssetImage(widget.image,height: FetchPixels.getPixelHeight(100),width: FetchPixels.getPixelWidth(200)),
            // getSvgImage("delete.svg"),
            getVerSpace(FetchPixels.getPixelHeight(30)),
            getPaddingWidget(
              EdgeInsets.symmetric(horizontal: FetchPixels.getPixelHeight(64)),
              getMultilineCustomFont(
                  widget.text,
                  16,
                  Colors.black,
                  fontWeight: FontWeight.w600,
                  txtHeight: FetchPixels.getPixelHeight(1.5),
                  textAlign: TextAlign.center),
            ),
            getVerSpace(FetchPixels.getPixelHeight(30)),
            getPaddingWidget(
              EdgeInsets.symmetric(horizontal: horSpace),
              Row(
                children: [
                  Expanded(
                    flex: 1,
                    child: InkWell(
                      onTap: (){
                        Get.back();
                      },
                      child: Container(
                        height:FetchPixels.getPixelHeight(60),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(
                                FetchPixels.getPixelHeight(35)),
                            color: R.colors.hintText),
                        child: Center(child:Text("NO",style: R.textStyle.mediumMontserrat().copyWith(fontSize: 16),)
                      ),
                      ),
                    ),
                  ),
                  getHorSpace(FetchPixels.getPixelHeight(25)),
                  Expanded(
                      flex: 1,
                      child: MyButton(
                        onTap: () {
                          Get.back();
                          widget.onTap();



                          },
                        buttonText: "YES",
                        color: R.colors.theme,
                      )

                      ),
                ],
              ),
            ),
            getVerSpace(FetchPixels.getPixelHeight(30)),
          ],
        ),
      ),
    );
  }
}
