import 'package:flutter/material.dart';

import '../resources/resources.dart';



MaterialColor primaryMaterialColor = const MaterialColor(
  0xFF000000,
  <int, Color>{
    50: Colors.black,
    100:Colors.black,
    200: Colors.black,
    300: Colors.black,
    400: Colors.black,
    500:Colors.black,
    600: Colors.black,
    700:Colors.black,
    800: Colors.black,
    900: Colors.black,
  },
);




ThemeData myTheme = ThemeData(

  backgroundColor: R.colors.bgColor,
  primaryColorDark: R.colors.whiteColor,
  fontFamily: "customFont",
  primaryColorLight:  R.colors.whiteColor,
  primaryColor: R.colors.whiteColor,
  primarySwatch: primaryMaterialColor,
  elevatedButtonTheme: ElevatedButtonThemeData(
    style: ElevatedButton.styleFrom(
      backgroundColor:  R.colors.borderColor,
    ),
  ),
);
