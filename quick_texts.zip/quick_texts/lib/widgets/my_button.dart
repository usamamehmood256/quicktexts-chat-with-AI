import 'package:flutter/material.dart';

import '../base/resizer/fetch_pixels.dart';
import '../base/widget_utils.dart';
import '../resources/resources.dart';

class MyButton extends StatefulWidget {
  final Function onTap;
  final String buttonText;
  final bool isPrefixIcon;
  final Color? color;
  final Color? textColor;
  final double? height;
  final double? width;

  MyButton(
      {required this.onTap,
      required this.buttonText,
      this.textColor,
      this.isPrefixIcon = false,
      this.color,
      this.height,
      this.width});
  @override
  _MyButtonState createState() => _MyButtonState();
}

class _MyButtonState extends State<MyButton> {
  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(35),
      onTap: () {
        widget.onTap();
      },
      child: Container(
        padding:
            EdgeInsets.symmetric(horizontal: FetchPixels.getPixelWidth(20)),
        height: widget.height ?? FetchPixels.getPixelHeight(60),
        width: FetchPixels.width,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(FetchPixels.getPixelHeight(35)),
          // border: Border.all(color: R.colors.whiteColor,width: 1),
          gradient: LinearGradient(
            colors: [
              R.colors.gradient1,
              R.colors.gradient2,
              R.colors.gradient3
            ],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            getVerSpace(FetchPixels.getPixelHeight(0.0)),
            Text(
              widget.buttonText,
              style: R.textStyle
                  .boldMontserrat()
                  .copyWith(color: R.colors.whiteColor),
            ),
            Icon(
              Icons.arrow_forward_ios_rounded,
              size: FetchPixels.getPixelHeight(20),
              color: R.colors.whiteColor.withOpacity(0.72),
            )
          ],
        ),
      ),
    );

    //   MaterialButton(
    //   shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15),
    //   side: BorderSide(color:R.colors.whiteColor,width: 2)
    //   ),
    //
    //   elevation: 0,
    //   minWidth: Get.width * 0.3,
    //   height: Get.height * .07,
    //   color: widget.color ?? R.colors.theme,
    //
    //   onPressed: () {
    //     widget.onTap();
    //   },
    // );
  }
}
