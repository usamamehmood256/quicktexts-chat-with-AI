import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:percent_indicator/linear_percent_indicator.dart';
import 'package:provider/provider.dart';
import 'package:quick_texts/screens/dashboard/pages/genrated_text_view.dart';
import 'package:quick_texts/screens/dashboard/pages/message_about_view.dart';
import 'package:quick_texts/screens/dashboard/pages/message_tone_view.dart';
import 'package:quick_texts/screens/dashboard/pages/recipient_name_page.dart';
import 'package:quick_texts/screens/dashboard/pages/select_message_type_view.dart';
import 'package:quick_texts/screens/dashboard/saved_messages_pages/saved_messages_view.dart';

import '../../base/resizer/fetch_pixels.dart';
import '../../base/widget_utils.dart';
import '../../resources/resources.dart';
import '../../routes/app_routes.dart';
import '../../utils/fb_collection.dart';
import '../../widgets/my_button.dart';
import '../auth/provider/auth_provider.dart';

class DashboardView extends StatefulWidget {
  const DashboardView({Key? key}) : super(key: key);

  @override
  State<DashboardView> createState() => _DashboardViewState();
}

class _DashboardViewState extends State<DashboardView> {
  @override
  void initState() {
    AuthProvider auth = Provider.of<AuthProvider>(context, listen: false);
    auth.contextCt = TextEditingController();
    auth.aboutTextCT = TextEditingController();
    auth.toneTextCT = TextEditingController();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<AuthProvider>(
      builder: (context, auth, child) {
        return Scaffold(backgroundColor: R.colors.bgColor,
          appBar: AppBar(
            backgroundColor: R.colors.bgColor,
            elevation: 0,
            centerTitle: true,
            title: getPaddingWidget(
              EdgeInsets.only(top: FetchPixels.getPixelHeight(20)),
               getAssetImage(R.images.logo,
                  height: FetchPixels.getPixelWidth(60),
                  width: FetchPixels.getPixelWidth(150)),
            ),
            leading: auth.currentPage == 0
                ? null
                : Center(
                    child: InkWell(
                      onTap: () {
                        auth.messagePC.animateToPage(auth.currentPage - 1,
                            duration: const Duration(milliseconds: 300),
                            curve: Curves.ease);

                        auth.update();
                      },
                      child: Container(
                        height: FetchPixels.getPixelHeight(40),
                        width: FetchPixels.getPixelWidth(40),
                        decoration: BoxDecoration(
                            color: R.colors.containerFill,
                            borderRadius: BorderRadius.circular(10)),
                        child: Center(
                            child: Icon(
                          Icons.arrow_back_ios_new_rounded,
                          size: 18,
                          color: R.colors.headingColor,
                        )),
                      ),
                    ),
                  ),
            actions: [
              Padding(
                padding: EdgeInsets.only(right: FetchPixels.getPixelWidth(10)),
                child: Center(
                  child: InkWell(
                    onTap: () {
                      Get.toNamed(Routes.settingsView);
                    },
                    child: Container(
                      height: FetchPixels.getPixelHeight(40),
                      width: FetchPixels.getPixelHeight(40),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: R.colors.circleFill),
                      child: Icon(Icons.settings,color: Color(0xff003049),),
                    ),
                  ),
                ),
              ),
            ],
          ),
          body: getPaddingWidget(
            EdgeInsets.symmetric(horizontal: FetchPixels.getPixelWidth(20)),
            SingleChildScrollView(
              child: Column(children: [
                getVerSpace(
                  FetchPixels.getPixelWidth(50),
                ),
                LinearPercentIndicator(
                  barRadius: const Radius.circular(10),
                  width: FetchPixels.getPixelWidth(350),
                  lineHeight: FetchPixels.getPixelHeight(8),
                  percent: auth.currentPage == 0
                      ? 0.2
                      : auth.currentPage == 1
                          ? 0.4
                          : auth.currentPage == 2
                              ? 0.6
                              : auth.currentPage == 3
                                  ? 0.8
                                  : 1.0,
                  backgroundColor: R.colors.progressFill.withOpacity(0.5),
                  progressColor: R.colors.gradient1,
                ),
                SizedBox(
                  height: FetchPixels.getPixelHeight(600),
                  width: FetchPixels.width,
                  child: PageView(
                    physics: NeverScrollableScrollPhysics(),
                    controller: auth.messagePC,
                    onPageChanged: (page) {
                      auth.currentPage = page;
                      auth.update();
                    },
                    children: [
                      MessageType(),
                      MessageAbout(),
                      MessageTone(),
                      RecipientName(),
                      GeneratedTextView(),
                    ],
                  ),
                ),
                getVerSpace(FetchPixels.getPixelHeight(20)),
                auth.isLoading == true && auth.currentPage == 3
                    ? Center(
                        child: CircularProgressIndicator(
                        strokeWidth: 10,
                        color: R.colors.theme,
                      ))
                    : MyButton(
                        onTap: auth.currentIndex == 0
                            ? () async {
                                textCompletion("prompt");
                                if (auth.currentPage == 3) {
                                  auth.startLoader();
                                  await textCompletion(
                                      "Write a ${(auth.toneMessageIndex == -1 ? auth.toneTextCT.text.trim() : auth.toneTexts[auth.toneMessageIndex].trim())} ${(auth.aboutCurrentIndex == -1 ? auth.aboutTextCT.text : auth.aboutTexts[auth.aboutCurrentIndex].trim())} text message.The context is: ${auth.contextCt.text.trim()}");

                                  auth.update();
                                  // print("This is:${auth.aboutTexts[auth.aboutCurrentIndex]}");
                                  // print("This is:${auth.toneTexts[auth.toneMessageIndex]}");
                                  print(
                                      "Write a ${(auth.toneMessageIndex == -1 ? auth.toneTextCT.text.trim() : auth.toneTexts[auth.toneMessageIndex].trim())} ${(auth.aboutCurrentIndex == -1 ? auth.aboutTextCT.text : auth.aboutTexts[auth.aboutCurrentIndex].trim())} text message.The context is: ${auth.contextCt.text.trim()}");

                                  auth.messagePC.animateToPage(
                                      auth.currentPage + 1,
                                      duration:
                                          const Duration(milliseconds: 300),
                                      curve: Curves.ease);
                                  auth.userModel.freeRequestLimit =
                                      auth.userModel.freeRequestLimit! + 1;
                                  FBCollections.users
                                      .doc(auth.userModel.email)
                                      .update({
                                    "freeRequestLimit":
                                        auth.userModel.freeRequestLimit,
                                  });
                                  auth.stopLoader();

                                  auth.update();
                                } else if (auth.currentPage == 4) {
                                  Get.offAll(DashboardView());
                                  auth.currentPage = 0;
                                  auth.toneMessageIndex = 0;
                                  auth.aboutCurrentIndex = 0;
                                  auth.contextCt.dispose();
                                  auth.aboutTextCT.dispose();
                                  auth.toneTextCT.dispose();

                                  auth.update();
                                } else {
                                  auth.messagePC.animateToPage(
                                      auth.currentPage + 1,
                                      duration:
                                          const Duration(milliseconds: 300),
                                      curve: Curves.ease);
                                }

                                auth.update();
                              }
                            : () {
                                Get.to(SavedMessageView());
                                // auth.messagePC.animateToPage(auth.currentPage+1,  duration: const Duration(milliseconds: 300),
                                //     curve: Curves.ease);
                              },
                        buttonText: auth.currentPage == 4
                            ? "Generate a New Text"
                            : "Continue")
              ]),
            ),
          ),
        );
      },
    );
  }
}
