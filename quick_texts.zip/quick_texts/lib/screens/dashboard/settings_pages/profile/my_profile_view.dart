
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

import '../../../../base/resizer/fetch_pixels.dart';
import '../../../../base/widget_utils.dart';
import '../../../../resources/resources.dart';
import '../../../../routes/app_routes.dart';
import '../../../../widgets/my_button.dart';
import '../../../auth/provider/auth_provider.dart';
class MyProfileView extends StatelessWidget {
  const MyProfileView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Consumer<AuthProvider>(builder: (context, auth, child) {


    return Scaffold(backgroundColor: R.colors.bgColor,
      appBar: AppBar(
        backgroundColor: R.colors.bgColor,
        elevation: 0,
        centerTitle: true,
        title: Text("PROFILE",style: R.textStyle.boldMontserrat().copyWith(fontSize: 16,color: R.colors.headingColor),),
        leading: Center(
          child: InkWell(
            onTap: () {
              Get.back();
            },
            child: Container(
              height: FetchPixels.getPixelHeight(40),
              width: FetchPixels.getPixelWidth(40),
              decoration: BoxDecoration(
                  color: R.colors.containerFill,
                  borderRadius: BorderRadius.circular(10)),
              child: Center(
                  child: Icon(
                    Icons.arrow_back_ios_new_rounded,
                    size: 18,
                    color: R.colors.headingColor,
                  )),
            ),
          ),
        ),
      ),
      body: getPaddingWidget(
        EdgeInsets.symmetric(horizontal: FetchPixels.getPixelWidth(20)),
        SingleChildScrollView(
          child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
getVerSpace(FetchPixels.getPixelHeight(30)),
            Align(alignment: Alignment.center,
              child: getAssetImage(R.images.logo,
                  height: FetchPixels.getPixelWidth(120),
                  width: FetchPixels.getPixelWidth(150)),
            ),
                getVerSpace(FetchPixels.getPixelHeight(50)),
            Text(
              "FULL NAME",
              style: R.textStyle
                  .semiBoldMontserrat()
                  .copyWith(fontSize: 12, color: R.colors.headingColor),
            ),
                getVerSpace(FetchPixels.getPixelHeight(10)),
            Container(
              height: FetchPixels.getPixelHeight(60),
              width: FetchPixels.width,
              decoration: BoxDecoration(
                  border: Border.all(
                      width: FetchPixels.getPixelWidth(0.8),
                      color: R.colors.borderColor),
                  borderRadius: BorderRadius.circular(6),
                  color: R.colors.whiteColor),
              child: Row(children: [
                getHorSpace(FetchPixels.getPixelWidth(10)),
                getHorSpace(FetchPixels.getPixelWidth(10)),
                Text(
                  auth.userModel.name!,
                  style: R.textStyle
                      .mediumMontserrat()
                      .copyWith(fontSize: 14, color: R.colors.headingColor),
                )
              ]),
            ),
                getVerSpace(FetchPixels.getPixelHeight(20)),
            Text(
              "EMAIL",
              style: R.textStyle
                  .semiBoldMontserrat()
                  .copyWith(fontSize: 12, color: R.colors.headingColor),
            ),
                getVerSpace(FetchPixels.getPixelHeight(10)),
            Container(
              height: FetchPixels.getPixelHeight(60),
              width: FetchPixels.width,
              decoration: BoxDecoration(
                  border: Border.all(
                      width: FetchPixels.getPixelWidth(0.8),
                      color: R.colors.borderColor),
                  borderRadius: BorderRadius.circular(6),
                  color: R.colors.whiteColor),
              child: Row(children: [
                getHorSpace(FetchPixels.getPixelWidth(10)),
                getHorSpace(FetchPixels.getPixelWidth(10)),
                Text(
                  auth.userModel.email!,
                  style: R.textStyle
                      .mediumMontserrat()
                      .copyWith(fontSize: 14, color: R.colors.headingColor),
                )
              ]),
            ),
                getVerSpace(FetchPixels.getPixelHeight(50)),
                MyButton(onTap: (){
Get.toNamed(Routes.editProfileVIew);
                }, buttonText: "Edit Profile")

          ]),
        ),

      ),
    );},);
  }
}
