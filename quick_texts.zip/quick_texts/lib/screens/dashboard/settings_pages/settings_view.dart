
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';

import '../../../base/resizer/fetch_pixels.dart';
import '../../../base/widget_utils.dart';
import '../../../dialogs/congrats_dialogue.dart';
import '../../../dialogs/delivered_order_dialogue.dart';
import '../../../resources/resources.dart';
import '../../../routes/app_routes.dart';
import '../../../widgets/my_button.dart';
import '../../auth/provider/auth_provider.dart';

class SettingsView extends StatelessWidget {
  SettingsView({Key? key}) : super(key: key);
  List<String> headings = [
    "My Profile",
    "Change Password",
    "Privacy Policy",
    "Terms & Conditions",
    "Get Subscription",
    "About us",
    "Share App",
    // "Delete Account",
  ];

  @override
  Widget build(BuildContext context) {
    return Consumer<AuthProvider>(builder: (context, auth, child) {


    return Scaffold(
      appBar: AppBar(
        backgroundColor: R.colors.bgColor,
        elevation: 0,
        centerTitle: true,
        title: getAssetImage(R.images.logo,
            height: FetchPixels.getPixelWidth(40),
            width: FetchPixels.getPixelWidth(150)),
        leading: Center(
          child: InkWell(
            onTap: () {
              Get.back();
            },
            child: Container(
              height: FetchPixels.getPixelHeight(40),
              width: FetchPixels.getPixelWidth(40),
              decoration: BoxDecoration(
                  color: R.colors.containerFill,
                  borderRadius: BorderRadius.circular(10)),
              child: Center(
                  child: Icon(
                Icons.arrow_back_ios_new_rounded,
                size: 18,
                color: R.colors.headingColor,
              )),
            ),
          ),
        ),
      ),
      body: SingleChildScrollView(
        child: getPaddingWidget(
          EdgeInsets.symmetric(horizontal: FetchPixels.getPixelWidth(20)),
          Column(children: [
            getVerSpace(FetchPixels.getPixelHeight(50)),
            Column(
              children: List.generate(headings.length, (index) {
                return Padding(
                  padding: EdgeInsets.symmetric(
                      vertical: FetchPixels.getPixelWidth(5)),
                  child: settingsWidget(index,auth),
                );
              }),
            ),
            getVerSpace(FetchPixels.getPixelHeight(30)),
            MyButton(
                onTap: () {
                  Get.dialog(OrderStatusDialog(
                    image: R.images.deleteAccount,
                    text: "Are You Sure You Wanna Logout?",
                    onTap: () async {
                      await auth.signOutQuery();
                      auth.update();
                    },
                  ));
                },
                buttonText: "Logout")
          ]),
        ),
      ),
    );},);
  }

  Widget settingsWidget(index,AuthProvider auth) {
    return InkWell(
      onTap: () {
        if (index == 7) {
          Get.dialog(OrderStatusDialog(
            onTap: () {
               // FBCollections.users.doc(auth.userModel.email).delete();
              Get.back();
              Get.dialog(CongratsDialogue(
                text: "You Have Successfully Delete Your Account",
                image: R.images.logo,
              ));
            },
            image: R.images.deleteAccount,
            text: "Are you sure you want to delete your account?",
          ));
        }
        else if(index==6) {

             Share.share('Your are Going to Share Your APP With Someone', subject: 'Sharing APP');

        }

        else {
          index == 0
              ? Get.toNamed(Routes.myProfileView)
              : index == 1
                  ? Get.toNamed(Routes.changePassword)
                  : index == 2
                      ? Get.toNamed(Routes.privacyPolicyView)
                      : index == 3
                          ? Get.toNamed(Routes.termsConditionsView)
                          : index==4?Get.toNamed(Routes.subscriptionPageView):index==5?Get.toNamed(Routes.aboutUsView):Get.toNamed(Routes.aboutUsView);
        }
      },
      child: Container(
        padding: EdgeInsets.all(FetchPixels.getPixelWidth(10)),
        height: FetchPixels.getPixelHeight(60),
        width: FetchPixels.width,
        decoration: BoxDecoration(
          border: Border.all(
              width: FetchPixels.getPixelWidth(0.8),
              color: R.colors.borderColor),
          borderRadius: BorderRadius.circular(6),
        ),
        child: Row(children: [
          Container(
            height: FetchPixels.getPixelHeight(22),
            width: FetchPixels.getPixelHeight(22),
            decoration: BoxDecoration(
                border: Border.all(
                    width: FetchPixels.getPixelWidth(4),
                    color: R.colors.circleFill),
                shape: BoxShape.circle,
                color: R.colors.circleFill),
          ),
          getHorSpace(FetchPixels.getPixelWidth(10)),
          Text(
            headings[index],
            style: R.textStyle
                .semiBoldMontserrat()
                .copyWith(fontSize: 14, color: R.colors.headingColor),
          ),
          Spacer(),
          Icon(
            Icons.arrow_forward_ios_rounded,
            size: FetchPixels.getPixelWidth(20),
          )
        ]),
      ),
    );
  }
}
