
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:provider/provider.dart';

import '../../../base/resizer/fetch_pixels.dart';
import '../../../base/widget_utils.dart';
import '../../../dialogs/congrats_dialogue1.dart';
import '../../../dialogs/delivered_order_dialogue.dart';
import '../../../resources/resources.dart';
import '../../../utils/fb_collection.dart';
import '../../../widgets/my_button.dart';
import '../../auth/provider/auth_provider.dart';

class SubscriptionPageView extends StatelessWidget {
  SubscriptionPageView({Key? key}) : super(key: key);
  int selectedSubscription = 0;
  List<String> features = [
    "Unlimited crafted texts",
    "Unlimited saved texts",
    "Access to all premium features",
    "Customizable emotion & occasion",
  ];
  @override
  Widget build(BuildContext context) {
    return Consumer<AuthProvider>(
      builder: (context, auth, child) {
        return Scaffold( backgroundColor: R.colors.bgColor,
          appBar: AppBar(
            backgroundColor: R.colors.bgColor,
            elevation: 0,
            centerTitle: true,
            title: getPaddingWidget(
              EdgeInsets.only(top: FetchPixels.getPixelHeight(10)),
               getAssetImage(R.images.logo,
                  height: FetchPixels.getPixelWidth(60),
                  width: FetchPixels.getPixelWidth(150)),
            ),
            leading: Center(
              child: InkWell(
                onTap: () {
                  Get.back();
                },
                child: Container(
                  height: FetchPixels.getPixelHeight(40),
                  width: FetchPixels.getPixelWidth(40),
                  decoration: BoxDecoration(
                      color: R.colors.containerFill,
                      borderRadius: BorderRadius.circular(10)),
                  child: Center(
                      child: Icon(
                    Icons.arrow_back_ios_new_rounded,
                    size: 18,
                    color: R.colors.headingColor,
                  )),
                ),
              ),
            ),
          ),
          body: getPaddingWidget(
            EdgeInsets.all(FetchPixels.getPixelHeight(20)),
            Column(children: [
              Column(
                children: List.generate(2, (index) {
                  return Padding(
                    padding: EdgeInsets.symmetric(
                        vertical: FetchPixels.getPixelHeight(10)),
                    child: subscription(index, auth),
                  );
                }),
              ),
              getVerSpace(FetchPixels.getPixelHeight(60)),
              MyButton(
                  onTap: () {
                    Get.dialog(OrderStatusDialog(
                      text: "Are You Sure You Want To Get Subscription?",
                      image: R.images.logo,
                      onTap: () async {
                        auth.userModel.isSubscribe = true;
                        print(auth.userModel.isSubscribe);
                        DateTime now = DateTime.now();
                        DateTime oneMonthFromNow =
                            DateTime(now.year, now.month + 1, now.day);
                        await FBCollections.users
                            .doc(auth.userModel.email)
                            .update({
                          "isSubscribe": auth.userModel.isSubscribe,
                          "startSubscription": DateTime.now(),
                          "endSubscription": Timestamp.fromDate(oneMonthFromNow)
                        });

                        auth.currentPage = 0;
                        auth.update();
                        Get.dialog(CongratsDialogue1(
                          image: R.images.logo,
                          text:
                              "You have subscribed. Enjoy all the premium features!",
                        ));
                      },
                    ));
                  },
                  buttonText: "Subscribe")
            ]),
          ),
        );
      },
    );
  }

  Widget subscription(index, AuthProvider auth) {
    return InkWell(
      onTap: () {
        auth.selectedSubscription = index;
        auth.update();
      },
      child: Container(
        padding: EdgeInsets.all(FetchPixels.getPixelHeight(20)),
        // height: FetchPixels.getPixelHeight(350),
        width: FetchPixels.width,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          color: R.colors.whiteColor,
        ),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(
            Icons.circle,
            color: auth.selectedSubscription == index
                ? R.colors.theme
                : R.colors.hintText,
            size: FetchPixels.getPixelHeight(20),
          ),
          getHorSpace(FetchPixels.getPixelWidth(10)),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  index == 0 ? "\$3.99 / Month" : "\$24.99 / Year",
                  style: R.textStyle
                      .semiBoldMontserrat()
                      .copyWith(fontSize: 14, color: R.colors.headingColor),
                ),
                getVerSpace(FetchPixels.getPixelHeight(10)),
                Column(
                  children: List.generate(features.length, (index) {
                    return subscriptionFeatures(index);
                  }),
                )
              ],
            ),
          )
        ]),
      ),
    );
  }

  Widget subscriptionFeatures(index) {
    return Padding(
      padding: const EdgeInsets.all(2.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(
            Icons.circle,
            size: 12,
            color: R.colors.hintText,
          ),
          getHorSpace(FetchPixels.getPixelWidth(10)),
          Expanded(
            child: Text(
              features[index],
              style: R.textStyle
                  .regularMontserrat()
                  .copyWith(fontSize: 14, color: R.colors.headingColor),
            ),
          ),
        ],
      ),
    );
  }
}
