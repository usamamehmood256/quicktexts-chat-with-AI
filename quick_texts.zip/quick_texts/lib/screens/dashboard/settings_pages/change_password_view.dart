import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:provider/provider.dart';

import '../../../base/resizer/fetch_pixels.dart';
import '../../../base/widget_utils.dart';
import '../../../dialogs/congrats_dialogue.dart';
import '../../../resources/resources.dart';
import '../../../utils/validator.dart';
import '../../../widgets/my_button.dart';
import '../../auth/provider/auth_provider.dart';

class ChangePassword extends StatefulWidget {
  const ChangePassword({Key? key}) : super(key: key);

  @override
  State<ChangePassword> createState() => _ChangePasswordState();
}

class _ChangePasswordState extends State<ChangePassword> {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  TextEditingController oldPasswordController = TextEditingController();

  FocusNode oldPassFN = FocusNode();

  TextEditingController newPasswordController = TextEditingController();

  FocusNode newPassFN = FocusNode();

  TextEditingController confirmPasswordController = TextEditingController();

  FocusNode conFirmPassFN = FocusNode();

  bool oldPassVisible = false;

  bool newPassVisible = false;

  bool confirmPassVisible = false;

  @override
  void dispose() {
    // TODO: implement dispose
    newPassFN.dispose();
    newPasswordController.dispose();
    oldPassFN.dispose();
    oldPasswordController.dispose();
    conFirmPassFN.dispose();
    confirmPasswordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<AuthProvider>(
      builder: (context, auth, child) {
        return Scaffold(
          appBar: AppBar(
            backgroundColor: R.colors.bgColor,
            elevation: 0,
            centerTitle: true,
            title: Text(
              "CHANGE PASSWORD",
              style: R.textStyle
                  .boldMontserrat()
                  .copyWith(fontSize: 16, color: R.colors.headingColor),
            ),
            leading: Center(
              child: InkWell(
                onTap: () {
                  Get.back();
                },
                child: Container(
                  height: FetchPixels.getPixelHeight(40),
                  width: FetchPixels.getPixelWidth(40),
                  decoration: BoxDecoration(
                      color: R.colors.containerFill,
                      borderRadius: BorderRadius.circular(10)),
                  child: Center(
                      child: Icon(
                    Icons.arrow_back_ios_new_rounded,
                    size: 18,
                    color: R.colors.headingColor,
                  )),
                ),
              ),
            ),
          ),
          backgroundColor: R.colors.bgColor,
          body: SingleChildScrollView(
            child: Form(
              key: formKey,
              autovalidateMode: AutovalidateMode.onUserInteraction,
              child: getPaddingWidget(
                EdgeInsets.symmetric(horizontal: FetchPixels.getPixelWidth(20)),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    getVerSpace(FetchPixels.getPixelHeight(20)),
                    getAssetImage(R.images.logo,
                        height: FetchPixels.getPixelHeight(120),
                        width: FetchPixels.getPixelWidth(200)),
                    getVerSpace(FetchPixels.getPixelHeight(10)),
                    Text(
                      "Change Password?",
                      style: R.textStyle.boldMontserrat().copyWith(
                            fontSize: 16,
                            color: R.colors.headingColor,
                          ),
                    ),
                    getVerSpace(FetchPixels.getPixelHeight(5)),
                    Text(
                      "Password Must Consist of at Least 6 Characters",
                      maxLines: 2,
                      style: R.textStyle.mediumMontserrat().copyWith(
                            fontSize: 13,
                            // color: R.colors.lightcolor,
                          ),
                      textAlign: TextAlign.center,
                    ),
                    getVerSpace(FetchPixels.getPixelHeight(40)),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        "Old Password",
                        style: R.textStyle.semiBoldMontserrat().copyWith(
                            fontSize: 12, color: R.colors.headingColor),
                      ),
                    ),
                    getVerSpace(FetchPixels.getPixelHeight(10)),
                    TextFormField(
                        autovalidateMode: AutovalidateMode.onUserInteraction,
                        style: R.textStyle
                            .mediumMontserrat()
                            .copyWith(color: R.colors.blackColor, fontSize: 14),
                        obscureText: oldPassVisible,
                        controller: oldPasswordController,
                        focusNode: oldPassFN,
                        onTap: () {
                          setState(() {});
                        },
                        keyboardType: TextInputType.visiblePassword,
                        textInputAction: TextInputAction.next,
                        validator: (value) =>
                            FieldValidator.validatePassword(value!),
                        decoration: R.decorations.textFormFieldDecoration(
                            InkWell(
                              onTap: () {
                                oldPassVisible = !oldPassVisible;
                                setState(() {});
                              },
                              child: Icon(
                                  !oldPassVisible
                                      ? Icons.visibility_off
                                      : Icons.visibility,
                                  color: oldPassFN.hasFocus
                                      ? R.colors.theme
                                      : R.colors.hintText),
                            ),
                            'Enter Old Password')),
                    getVerSpace(FetchPixels.getPixelHeight(20)),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        "New Password",
                        style: R.textStyle.semiBoldMontserrat().copyWith(
                            fontSize: 12, color: R.colors.headingColor),
                      ),
                    ),
                    getVerSpace(FetchPixels.getPixelHeight(10)),
                    TextFormField(
                        autovalidateMode: AutovalidateMode.onUserInteraction,
                        style: R.textStyle
                            .mediumMontserrat()
                            .copyWith(color: R.colors.blackColor, fontSize: 14),
                        obscureText: newPassVisible,
                        controller: newPasswordController,
                        focusNode: newPassFN,
                        onTap: () {
                          setState(() {});
                        },
                        keyboardType: TextInputType.visiblePassword,
                        textInputAction: TextInputAction.next,
                        validator: (value) =>
                            FieldValidator.validatePassword(value!),
                        decoration: R.decorations.textFormFieldDecoration(
                            InkWell(
                              onTap: () {
                                newPassVisible = !newPassVisible;
                                setState(() {});
                              },
                              child: Icon(
                                  !newPassVisible
                                      ? Icons.visibility_off
                                      : Icons.visibility,
                                  color: newPassFN.hasFocus
                                      ? R.colors.theme
                                      : R.colors.hintText),
                            ),
                            'Enter Password')),
                    getVerSpace(FetchPixels.getPixelHeight(10)),
                    TextFormField(
                        autovalidateMode: AutovalidateMode.onUserInteraction,
                        keyboardType: TextInputType.name,
                        textInputAction: TextInputAction.next,
                        style: R.textStyle
                            .mediumMontserrat()
                            .copyWith(color: R.colors.blackColor, fontSize: 14),
                        obscureText: confirmPassVisible,
                        controller: confirmPasswordController,
                        focusNode: conFirmPassFN,
                        onTap: () {
                          setState(() {});
                        },
                        validator: (value) =>
                            FieldValidator.validatePasswordMatch(
                                value!, newPasswordController.text),
                        decoration: R.decorations.textFormFieldDecoration(
                            InkWell(
                                onTap: () {
                                  confirmPassVisible = !confirmPassVisible;
                                  setState(() {});
                                },
                                child: Icon(
                                  !confirmPassVisible
                                      ? Icons.visibility_off
                                      : Icons.visibility,
                                  color: conFirmPassFN.hasFocus
                                      ? R.colors.theme
                                      : R.colors.hintText,
                                )),
                            'Confirm Password')),
                    getVerSpace(FetchPixels.getPixelHeight(40)),
                    auth.isLoading == true
                        ? Center(
                        child: CircularProgressIndicator(
                          strokeWidth: 10,
                          color: R.colors.theme,
                        ))
                        : MyButton(
                        onTap: () {
                          if (formKey.currentState!.validate()) {
                            auth.changePassword(
                                newPassword: confirmPasswordController.text.trim(),
                                oldPassword: oldPasswordController.text.trim());
                            auth.update();
                          }
                        },
                        buttonText: "UPDATE")
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
