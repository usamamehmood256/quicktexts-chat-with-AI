
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';

import '../../../base/resizer/fetch_pixels.dart';
import '../../../base/widget_utils.dart';
import '../../../resources/resources.dart';
import '../../auth/provider/auth_provider.dart';

class SavedMessageView extends StatelessWidget {
  SavedMessageView({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Consumer<AuthProvider>(
      builder: (context, auth, child) {
        return Scaffold(
          appBar: AppBar(
            backgroundColor: R.colors.bgColor,
            elevation: 0,
            centerTitle: true,
            title: Text(
              "Saved Text",
              style: R.textStyle
                  .semiBoldMontserrat()
                  .copyWith(fontSize: 16, color: R.colors.headingColor),
            ),
            leading: Center(
              child: InkWell(
                onTap: () {
                  Get.back();
                },
                child: Container(
                  height: FetchPixels.getPixelHeight(40),
                  width: FetchPixels.getPixelWidth(40),
                  decoration: BoxDecoration(
                      color: R.colors.containerFill,
                      borderRadius: BorderRadius.circular(10)),
                  child: Center(
                      child: Icon(
                    Icons.arrow_back_ios_new_rounded,
                    size: 18,
                    color: R.colors.headingColor,
                  )),
                ),
              ),
            ),
          ),
          body: auth.userModel.savedMessages!.isEmpty
              ? Center(
                  child: Text(
                  "There is no Saved Message Available",
                  style: R.textStyle.semiBoldMontserrat().copyWith(
                      fontSize: 15,
                      color: R.colors.headingColor.withOpacity(0.5)),
                ))
              : ListView.builder(
                  itemCount: auth.userModel.savedMessages!.length,
                  padding: EdgeInsets.symmetric(
                      horizontal: FetchPixels.getPixelWidth(20)),
                  itemBuilder: (context, index) {
                    String user = auth.userModel.savedMessages![index];
                    return getPaddingWidget(
                      EdgeInsets.symmetric(
                          vertical: FetchPixels.getPixelHeight(10)),
                      messageWidget(user, index),
                    );
                  },
                ),
        );
      },
    );
  }

  Widget messageWidget(String userModel, index) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Container(
          padding: EdgeInsets.all(FetchPixels.getPixelHeight(20)),
          width: FetchPixels.getPixelWidth(280),
          decoration: BoxDecoration(
              color: R.colors.whiteColor,
              borderRadius: BorderRadius.circular(14)),
          child: Text(userModel.trim()),
        ),
        InkWell(
          onTap: () async {
            await Share.share('${userModel.trim()}', subject: 'Sharing text');
          },
          child: Container(
            padding: EdgeInsets.all(FetchPixels.getPixelHeight(10)),
            decoration: BoxDecoration(
                color: R.colors.borderColor, shape: BoxShape.circle),
            child: Icon(
              Icons.send,
              color: R.colors.theme,
            ),
          ),
        )
      ],
    );
  }
}
