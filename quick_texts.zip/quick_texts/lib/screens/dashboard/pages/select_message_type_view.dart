
import 'package:flutter/material.dart';

import 'package:get/get.dart';

import 'package:get/get_core/src/get_main.dart';
import 'package:provider/provider.dart';

import '../../../base/resizer/fetch_pixels.dart';
import '../../../base/widget_utils.dart';
import '../../../resources/resources.dart';
import '../../../routes/app_routes.dart';
import '../../auth/provider/auth_provider.dart';

class MessageType extends StatelessWidget {
  MessageType({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Consumer<AuthProvider>(
      builder: (context, auth, child) {
        return Column(
          children: [
            getVerSpace(FetchPixels.getPixelHeight(50)),
            Text(
              "What kind of message are\nyou sending?",
              textAlign: TextAlign.center,
              style: R.textStyle
                  .boldMontserrat()
                  .copyWith(fontSize: 18, color: R.colors.headingColor),
            ),
            getVerSpace(FetchPixels.getPixelHeight(20)),
            Column(
              children: List.generate(2, (index) {
                return Padding(
                  padding: EdgeInsets.symmetric(
                      vertical: FetchPixels.getPixelHeight(20)),
                  child: selectType(index, auth),
                );
              }),
            )
          ],
        );
      },
    );
  }

  Widget selectType(index, AuthProvider auth) {
    return InkWell(
      onTap: () {
        auth.userModel.isSubscribe == false && index == 1
            ? Get.toNamed(Routes.subscriptionPageView)
            // Get.dialog(OrderStatusDialog(
            //         image: R.images.logo,
            //         text:
            //             "This Option Is Only For Premium User\nAre You Sure You Want To Get Subscription?",
            //         onTap: () {
            //           Get.toNamed(Routes.subscriptionPageView);
            //         },
            //       ))
            : auth.currentIndex = index;
        print({"THis is IS SUBSCRIBED ${auth.userModel.isSubscribe}"});
        auth.update();
      },
      child: Container(
        height: FetchPixels.getPixelHeight(80),
        width: FetchPixels.width,
        decoration: BoxDecoration(
          color: R.colors.whiteColor,
          boxShadow: [
            BoxShadow(
                color: R.colors.headingColor.withOpacity(0.1),
                blurRadius: 5,
                spreadRadius: 3)
          ],
          borderRadius: BorderRadius.circular(14),
          gradient: auth.currentIndex == index
              ? LinearGradient(
                  colors: [
                    R.colors.gradient1,
                    R.colors.gradient2,
                    R.colors.gradient3
                  ],
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                )
              : LinearGradient(
                  colors: [
                    R.colors.whiteColor,
                    R.colors.whiteColor,
                    R.colors.whiteColor,
                  ],
                ),
        ),
        child: Row(children: [
          getAssetImage(
            index == 0 ? R.images.newMessage : R.images.savedMessages,
            color: auth.currentIndex == index
                ? R.colors.whiteColor
                : R.colors.headingColor,
            height: FetchPixels.getPixelHeight(index == 0 ? 40 : 30),
            width: FetchPixels.getPixelHeight(70),
          ),
          Text(
            index == 0
                ? "Create a New Message"
                : (auth.userModel.isSubscribe == false
                    ? "Saved Messages(Premium)"
                    : "Saved Messages"),
            style: R.textStyle.semiBoldMontserrat().copyWith(
                fontSize: 16,
                color: auth.currentIndex == index
                    ? R.colors.whiteColor
                    : R.colors.headingColor),
          )
        ]),
      ),
    );
  }
}
