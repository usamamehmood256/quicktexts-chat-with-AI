import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:provider/provider.dart';
import '../../../base/resizer/fetch_pixels.dart';

import '../../../base/widget_utils.dart';
import '../../../resources/resources.dart';
import '../../../routes/app_routes.dart';
import '../../auth/provider/auth_provider.dart';

class MessageAbout extends StatelessWidget {
  MessageAbout({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Consumer<AuthProvider>(
      builder: (context, auth, child) {
        return Column(
          children: [
            getVerSpace(FetchPixels.getPixelHeight(50)),
            Text(
              "What is the text message\nabout?",
              textAlign: TextAlign.center,
              style: R.textStyle
                  .boldMontserrat()
                  .copyWith(fontSize: 18, color: R.colors.headingColor),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: auth.aboutTexts.length,
                itemBuilder: (context, index) {
                  return Padding(
                    padding: EdgeInsets.symmetric(
                        vertical: FetchPixels.getPixelHeight(10)),
                    child: index == auth.aboutTexts.length - 1 &&
                            (auth.userModel.isSubscribe == true ||
                                auth.userModel.freeRequestLimit! <= 24)
                        ?

                    TextFormField(
                            keyboardType: TextInputType.text,
                            textInputAction: TextInputAction.done,
                            onTap: () {
                              auth.aboutCurrentIndex = -1;
                              print("This is index:${auth.aboutCurrentIndex}");
                              auth.update();
                            },
                            // onChanged: (value) {
                            //   return auth.update();
                            // },
                            focusNode: auth.aboutCurrentIndex == -1
                                ? auth.customTextFN
                                : null,
                            cursorColor: R.colors.theme,
                            style: R.textStyle.semiBoldMontserrat().copyWith(
                                fontSize: 15, color: R.colors.headingColor),
                            controller: auth.aboutTextCT,
                            decoration: R.decorations
                                .textFormFieldDecoration(
                                    null,auth.userModel.isSubscribe==true? "Custom":"Custom(Premium)")
                                .copyWith(
                                    prefixIcon: Icon(
                                  Icons.circle,
                                  size: FetchPixels.getPixelHeight(25),
                                  color: auth.customTextFN.hasFocus
                                      ? R.colors.theme
                                      : R.colors.circleFill,
                                )),
                          )
                        : aboutMessage(index, auth),
                  );
                },
              ),
            )
          ],
        );
      },
    );
  }

  Widget aboutMessage(index, AuthProvider auth) {
    return InkWell(
      onTap: () {
        if (index == auth.aboutTexts.length - 1 &&
            (auth.userModel.freeRequestLimit! > 24 &&
                auth.userModel.isSubscribe == false)) {
          Get.toNamed(Routes.subscriptionPageView);
          // Get.dialog(OrderStatusDialog(
          //   image: R.images.logo,
          //   text:
          //       "This Option Is Only For Premium User\nAre You Sure You Want To Get Subscription?",
          //   onTap: () {
          //     Get.toNamed(Routes.subscriptionPageView);
          //   },
          // ));
        } else {
          auth.aboutCurrentIndex = index;
          auth.update();
        }

        print(auth.aboutTexts[index]);
        auth.update();
      },
      child: Container(
        height: FetchPixels.getPixelHeight(60),
        width: FetchPixels.width,
        decoration: BoxDecoration(
          border: Border.all(
              width: FetchPixels.getPixelWidth(0.8),
              color: R.colors.borderColor),
          borderRadius: BorderRadius.circular(6),
          gradient: auth.aboutCurrentIndex == index
              ? LinearGradient(
                  colors: [
                    R.colors.gradient1,
                    R.colors.gradient2,
                    R.colors.gradient3
                  ],
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                )
              : LinearGradient(
                  colors: [
                    R.colors.whiteColor,
                    R.colors.whiteColor,
                    R.colors.whiteColor,
                  ],
                ),
        ),
        child: Row(children: [
          getHorSpace(FetchPixels.getPixelWidth(10)),
          Container(
            height: FetchPixels.getPixelHeight(22),
            width: FetchPixels.getPixelHeight(22),
            decoration: BoxDecoration(
                border: Border.all(
                    width: FetchPixels.getPixelWidth(4),
                    color: auth.aboutCurrentIndex == index
                        ? R.colors.whiteColor
                        : R.colors.circleFill),
                shape: BoxShape.circle,
                color: auth.aboutCurrentIndex == index
                    ? R.colors.transparent
                    : R.colors.circleFill),
          ),
          getHorSpace(FetchPixels.getPixelWidth(10)),
          Text(
            auth.aboutTexts[index],
            style: R.textStyle.semiBoldMontserrat().copyWith(
                fontSize: 14,
                color: auth.aboutCurrentIndex == index
                    ? R.colors.whiteColor
                    : R.colors.headingColor),
          )
        ]),
      ),
    );
  }
}
