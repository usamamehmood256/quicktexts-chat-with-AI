import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../base/resizer/fetch_pixels.dart';
import '../../../base/widget_utils.dart';
import '../../../resources/resources.dart';
import '../../auth/provider/auth_provider.dart';

class RecipientName extends StatelessWidget {
  RecipientName({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Consumer<AuthProvider>(builder: (context, auth, child) {


    return Column(
      children: [
        getVerSpace(FetchPixels.getPixelHeight(50)),
        Text(
          "Please add any other\ncontext (optional)",
          textAlign: TextAlign.center,
          style: R.textStyle
              .boldMontserrat()
              .copyWith(fontSize: 18, color: R.colors.headingColor),
        ),
        getVerSpace(FetchPixels.getPixelHeight(50)),
        TextFormField(
          controller: auth.contextCt,
          cursorColor: R.colors.hintText,
          autovalidateMode: AutovalidateMode.onUserInteraction,
          keyboardType: TextInputType.text,
          textInputAction: TextInputAction.done,
          style: R.textStyle
              .mediumMontserrat()
              .copyWith(color: R.colors.blackColor, fontSize: 14),
          decoration: R.decorations
              .textFormFieldDecoration(null, "Type here..."),
        ),
      ],
    );},);
  }
}
