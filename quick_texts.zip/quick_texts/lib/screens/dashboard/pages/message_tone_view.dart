import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:provider/provider.dart';

import '../../../base/resizer/fetch_pixels.dart';
import '../../../base/widget_utils.dart';
import '../../../dialogs/delivered_order_dialogue.dart';
import '../../../resources/resources.dart';
import '../../../routes/app_routes.dart';
import '../../auth/provider/auth_provider.dart';

class MessageTone extends StatelessWidget {
  MessageTone({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Consumer<AuthProvider>(
      builder: (context, auth, child) {
        return Column(
          children: [
            getVerSpace(FetchPixels.getPixelHeight(50)),
            Text(
              "What is the tone of the text\nmessage?",
              textAlign: TextAlign.center,
              style: R.textStyle
                  .boldMontserrat()
                  .copyWith(fontSize: 18, color: R.colors.headingColor),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: auth.toneTexts.length,
                itemBuilder: (context, index) {
                  return Padding(
                    padding: EdgeInsets.symmetric(
                        vertical: FetchPixels.getPixelHeight(10)),
                    child: index == auth.toneTexts.length - 1 &&
                            (auth.userModel.isSubscribe == true || auth.userModel.freeRequestLimit! <=25)
                        ? TextFormField(
                            focusNode: auth.tonCustomTextFN,
                            keyboardType: TextInputType.text,
                            textInputAction: TextInputAction.done,
                            onTap: () {
                              auth.toneMessageIndex = -1;
                              auth.update();
                            },
                            cursorColor: R.colors.theme,
                            style: R.textStyle.semiBoldMontserrat().copyWith(
                                fontSize: 15, color: R.colors.headingColor),
                            controller: auth.toneTextCT,
                            decoration: R.decorations
                                .textFormFieldDecoration(
                                    null,auth.userModel.isSubscribe==true?"Custom": "Custom(Premium)")
                                .copyWith(
                                    prefixIcon: Icon(
                                  Icons.circle,
                                  size: FetchPixels.getPixelHeight(25),
                                  color: auth.tonCustomTextFN.hasFocus
                                      ? R.colors.theme
                                      : R.colors.circleFill,
                                )),
                          )
                        : toneMessage(index, auth),
                  );
                },
              ),
            )
          ],
        );
      },
    );
  }

  Widget toneMessage(index, AuthProvider auth) {
    return InkWell(
      onTap: () {
        if (auth.userModel.freeRequestLimit! <= 24 &&
            auth.userModel.isSubscribe == false) {
          auth.toneMessageIndex = index;
        }
        else if (auth.userModel.freeRequestLimit! > 24 &&
            auth.userModel.isSubscribe == false && index > 1 ) {
          Get.toNamed(Routes.subscriptionPageView);
          // Get.dialog(OrderStatusDialog(
          //   image: R.images.logo,
          //   text:
          //       "This Option Is Only For Premium User\nAre You Sure You Want To Get Subscription?",
          //   onTap: () {
          //     Get.toNamed(Routes.subscriptionPageView);
          //   },
          // ));
        } else if (auth.userModel.isSubscribe == true || index < 3) {
          auth.toneMessageIndex = index;
          auth.update();
        } else {
          auth.update();
        }
        print(auth.toneTexts[auth.toneMessageIndex]);
        auth.update();
      },
      child: Container(
        height: FetchPixels.getPixelHeight(60),
        width: FetchPixels.width,
        decoration: BoxDecoration(
          border: Border.all(
              width: FetchPixels.getPixelWidth(0.8),
              color: R.colors.borderColor),
          borderRadius: BorderRadius.circular(6),
          gradient: auth.toneMessageIndex == index
              ? LinearGradient(
                  colors: [
                    R.colors.gradient1,
                    R.colors.gradient2,
                    R.colors.gradient3
                  ],
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                )
              : LinearGradient(
                  colors: [
                    R.colors.whiteColor,
                    R.colors.whiteColor,
                    R.colors.whiteColor,
                  ],
                ),
        ),
        child: Row(children: [
          getHorSpace(FetchPixels.getPixelWidth(10)),
          Container(
            height: FetchPixels.getPixelHeight(22),
            width: FetchPixels.getPixelHeight(22),
            decoration: BoxDecoration(
                border: Border.all(
                    width: FetchPixels.getPixelWidth(4),
                    color: auth.toneMessageIndex == index
                        ? R.colors.whiteColor
                        : R.colors.circleFill),
                shape: BoxShape.circle,
                color: auth.toneMessageIndex == index
                    ? R.colors.transparent
                    : R.colors.circleFill),
          ),
          getHorSpace(FetchPixels.getPixelWidth(10)),
          Text(
            auth.toneTexts[index],
            style: R.textStyle.semiBoldMontserrat().copyWith(
                fontSize: 14,
                color: auth.toneMessageIndex == index
                    ? R.colors.whiteColor
                    : R.colors.headingColor),
          ),
          index>1 && auth.userModel.isSubscribe== false?  Text(
            "(Premium)",
            style: R.textStyle.semiBoldMontserrat().copyWith(
                fontSize: 14,
                color: auth.toneMessageIndex == index
                    ? R.colors.whiteColor
                    : R.colors.headingColor),
          ):SizedBox(),
        ]),
      ),
    );
  }
}
