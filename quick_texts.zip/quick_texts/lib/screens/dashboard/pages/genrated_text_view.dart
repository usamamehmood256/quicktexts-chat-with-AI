
import 'package:chat_gpt_api/chat_gpt.dart';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';

import '../../../base/resizer/fetch_pixels.dart';
import '../../../base/widget_utils.dart';
import '../../../resources/resources.dart';
import '../../../routes/app_routes.dart';
import '../../../utils/fb_collection.dart';
import '../../../utils/show_message.dart';
import '../../auth/model/model.dart';
import '../../auth/provider/auth_provider.dart';

 // const apiKey = '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';
    const apiKey = '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';


class GeneratedTextView extends StatefulWidget {
  GeneratedTextView({Key? key}) : super(key: key);

  @override
  State<GeneratedTextView> createState() => _GeneratedTextViewState();
}

class _GeneratedTextViewState extends State<GeneratedTextView> {
  TextEditingController textMessageCT = TextEditingController();

  FocusNode textFN = FocusNode();

  @override
  Widget build(BuildContext context) {
    return Consumer<AuthProvider>(
      builder: (context, auth, child) {
        return SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              getVerSpace(FetchPixels.getPixelWidth(20)),
              getVerSpace(FetchPixels.getPixelWidth(20)),
              Text(
                "OCCASION",
                style: R.textStyle
                    .semiBoldMontserrat()
                    .copyWith(fontSize: 12, color: R.colors.headingColor),
              ),
              getVerSpace(FetchPixels.getPixelWidth(10)),
              Container(
                height: FetchPixels.getPixelHeight(60),
                width: FetchPixels.width,
                decoration: BoxDecoration(
                    border: Border.all(
                        width: FetchPixels.getPixelWidth(0.8),
                        color: R.colors.borderColor),
                    borderRadius: BorderRadius.circular(6),
                    color: R.colors.whiteColor),
                child: Row(children: [
                  getHorSpace(FetchPixels.getPixelWidth(10)),
                  getHorSpace(FetchPixels.getPixelWidth(10)),
                  Text(
                    auth.aboutCurrentIndex == -1
                        ? auth.aboutTextCT.text
                        : auth.aboutTexts[auth.aboutCurrentIndex],
                    style: R.textStyle
                        .mediumMontserrat()
                        .copyWith(fontSize: 14, color: R.colors.headingColor),
                  )
                ]),
              ),
              getVerSpace(FetchPixels.getPixelWidth(20)),
              Text(
                "EMOTION",
                style: R.textStyle
                    .semiBoldMontserrat()
                    .copyWith(fontSize: 12, color: R.colors.headingColor),
              ),
              getVerSpace(FetchPixels.getPixelWidth(10)),
              Container(
                height: FetchPixels.getPixelHeight(60),
                width: FetchPixels.width,
                decoration: BoxDecoration(
                    border: Border.all(
                        width: FetchPixels.getPixelWidth(0.8),
                        color: R.colors.borderColor),
                    borderRadius: BorderRadius.circular(6),
                    color: R.colors.whiteColor),
                child: Row(children: [
                  getHorSpace(FetchPixels.getPixelWidth(20)),
                  Text(
                    auth.toneMessageIndex == -1
                        ? auth.toneTextCT.text
                        : auth.toneTexts[auth.toneMessageIndex],
                    style: R.textStyle
                        .mediumMontserrat()
                        .copyWith(fontSize: 14, color: R.colors.headingColor),
                  )
                ]),
              ),
              getVerSpace(FetchPixels.getPixelWidth(20)),
              Text(
                "CONTEXT",
                style: R.textStyle
                    .semiBoldMontserrat()
                    .copyWith(fontSize: 12, color: R.colors.headingColor),
              ),
              getVerSpace(FetchPixels.getPixelWidth(10)),
              Container(
                  padding: EdgeInsets.all(FetchPixels.getPixelHeight(20)),
                  // height: FetchPixels.getPixelHeight(60),
                  width: FetchPixels.width,
                  decoration: BoxDecoration(
                      border: Border.all(
                          width: FetchPixels.getPixelWidth(0.8),
                          color: R.colors.borderColor),
                      borderRadius: BorderRadius.circular(6),
                      color: R.colors.whiteColor),
                  child: Text(
                    auth.contextCt.text,
                    // maxLines: 5,
                    // overflow: TextOverflow.ellipsis,
                    style: R.textStyle
                        .mediumMontserrat()
                        .copyWith(fontSize: 14, color: R.colors.headingColor),
                  )),
              getVerSpace(FetchPixels.getPixelHeight(20)),
              Text(
                "GENERATED TEXT",
                style: R.textStyle
                    .semiBoldMontserrat()
                    .copyWith(fontSize: 12, color: R.colors.headingColor),
              ),
              getVerSpace(FetchPixels.getPixelWidth(10)),
              Container(
                padding: EdgeInsets.symmetric(
                    horizontal: FetchPixels.getPixelHeight(20)),
                // height: FetchPixels.getPixelHeight(250),
                width: FetchPixels.width,
                decoration: BoxDecoration(
                    border: Border.all(
                        width: FetchPixels.getPixelWidth(0.8),
                        color: R.colors.theme),
                    borderRadius: BorderRadius.circular(6),
                    color: R.colors.whiteColor),
                child: Column(
                    // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    // crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      getVerSpace(FetchPixels.getPixelHeight(15)),
                      Text(
                        R.dummyData.longerText,
                        // completion!.choices!.first.text ?? "",
                        style: R.textStyle.regularMontserrat().copyWith(
                            fontSize: 16, color: R.colors.headingColor),
                      ),
                      getDivider(
                        R.colors.hintText,
                        FetchPixels.getPixelHeight(30),
                        FetchPixels.getPixelHeight(0.5),
                      ),
                      InkWell(
                        onTap: () {
                          final data = ClipboardData(
                            text: R.dummyData.longerText,
                              // text: completion!.choices!.first.text ?? ""
                          );
                          Clipboard.setData(data);
                          print(data);
                          ShowMessage.inSnackBar(
                              "------------------------------",
                              "Your Text is Copied to Clipboard!");
                          // Get.snackbar(
                          //     backgroundColor: R.colors.theme,
                          //     colorText: R.colors.whiteColor,
                          //     "ALERT!",
                          //     "Your Text is Copied to Clipboard!");
                        },
                        child: Row(
                          children: [
                            getAssetImage(R.images.copyIcon,
                                height: FetchPixels.getPixelHeight(25),
                                width: FetchPixels.getPixelWidth(25)),
                            getHorSpace(FetchPixels.getPixelWidth(10)),
                            Text(
                              "copy text message",
                              style: R.textStyle.mediumMontserrat().copyWith(
                                  fontSize: 15, color: R.colors.hintText),
                            )
                          ],
                        ),
                      ),
                      getDivider(
                        R.colors.hintText,
                        FetchPixels.getPixelHeight(30),
                        FetchPixels.getPixelHeight(0.5),
                      ),
                      InkWell(
                        onTap: () async {
                          await Share.share(
                              R.dummyData.longerText,

                              // completion!.choices!.first.text ?? "",
                              subject: 'Sharing text');
                        },
                        child: Row(
                          children: [
                            getAssetImage(R.images.shareIcon,
                                height: FetchPixels.getPixelHeight(25),
                                width: FetchPixels.getPixelWidth(25)),
                            getHorSpace(FetchPixels.getPixelWidth(10)),
                            Text(
                              "Share text message",
                              style: R.textStyle.mediumMontserrat().copyWith(
                                  fontSize: 15, color: R.colors.hintText),
                            )
                          ],
                        ),
                      ),
                      getDivider(
                        R.colors.hintText,
                        FetchPixels.getPixelHeight(30),
                        FetchPixels.getPixelHeight(0.5),
                      ),
                      InkWell(
                        onTap: () async {
                          if (auth.userModel.isSubscribe == false) {
                            Get.toNamed(Routes.subscriptionPageView);
                            // Get.dialog(OrderStatusDialog(
                            //   image: R.images.logo,
                            //   text:
                            //       "This Option Is Only For Premium User\nAre You Sure You Want To Get Subscription?",
                            //   onTap: () {
                            //     Get.toNamed(Routes.subscriptionPageView);
                            //   },
                            // ));
                          } else {
                            // FBCollections.users.doc(auth.userModel.email).update(data);
                            auth.userModel.savedMessages!
                                .add(R.dummyData.longerText,);
                            UserModel userModel = UserModel(
                                savedMessages: auth.userModel.savedMessages,
                                email: auth.userModel.email,
                                name: auth.userModel.name,
                                endSubscription: auth.userModel.endSubscription,
                                isSubscribe: auth.userModel.isSubscribe,
                                freeRequestLimit:
                                    auth.userModel.freeRequestLimit,
                                startSubscription:
                                    auth.userModel.startSubscription);
                            await FBCollections.users
                                .doc(auth.userModel.email)
                                .update(userModel.toJson())
                                .then((value) {
                              Get.snackbar(
                                  backgroundColor: R.colors.theme,
                                  colorText: R.colors.whiteColor,
                                  "----------------",
                                  "Your Text is Saved");
                            });
                          }
                        },
                        child: Row(
                          children: [
                            getAssetImage(R.images.downloadIcon,
                                height: FetchPixels.getPixelHeight(25),
                                width: FetchPixels.getPixelWidth(25)),
                            getHorSpace(FetchPixels.getPixelWidth(10)),
                            Text(
                              auth.userModel.isSubscribe == false
                                  ? "Save text message  (Premium)"
                                  : "Save text message",
                              style: R.textStyle.mediumMontserrat().copyWith(
                                  fontSize: 15, color: R.colors.hintText),
                            )
                          ],
                        ),
                      ),
                      getVerSpace(FetchPixels.getPixelHeight(20)),
                    ]),
              ),
            ],
          ),
        );
      },
    );
  }
}

final chatGpt = ChatGPT.builder(

  token: apiKey, // generate token from https://beta.openai.com/account/api-keys
);
Completion? completion;

Future textCompletion(String? prompt) async {
   completion = await chatGpt.textCompletion(
    request: CompletionRequest(
      prompt: prompt!,
      maxTokens: 2000,
      model: "text-davinci-002",
    ),
  );

   // print("This is flutter gpt:${completion!.choices!.first.text}");
}


