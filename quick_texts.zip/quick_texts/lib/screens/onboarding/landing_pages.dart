import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../resources/resources.dart';
import '../../../routes/app_routes.dart';
import '../../base/resizer/fetch_pixels.dart';
import '../../base/widget_utils.dart';

class LandingPage extends StatefulWidget {
  const LandingPage({
    Key? key,
  }) : super(key: key);

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage> {
  PageController pageController = PageController();
  int currentPage = 0;
  var height, width;
  List<String> CongratsBottomSheets = [
    "Craft amazing texts for any situation, Automagically",
    "Customize your texts for Greater Reaction",
    "Never waste time thinking of the perfect text again",
  ];
  @override
  Widget build(BuildContext context) {
    height = MediaQuery.of(context).size.height;
    width = MediaQuery.of(context).size.width;
    return Scaffold(

        body: getPaddingWidget(
          EdgeInsets.symmetric(horizontal: FetchPixels.getPixelWidth(30)),
          SingleChildScrollView(

            child: Column(
              children: [
                getAssetImage(R.images.logo,
                    height: FetchPixels.getPixelHeight(220),
                    width: FetchPixels.getPixelWidth(180)),
                getVerSpace(FetchPixels.getPixelHeight(30)),
                SizedBox(
                  height: FetchPixels.getPixelHeight(300),
                  width: FetchPixels.width,
                  child: PageView(
                    controller: pageController,
                    onPageChanged: (page) {
                      currentPage = page;
                      setState(() {});
                    },
                    children: [
                      getAssetImage(R.images.landing1,
                          height: FetchPixels.getPixelHeight(350)),
                      getAssetImage(
                        R.images.landing2,
                      ),
                      getAssetImage(
                        R.images.landing3,
                      ),
                    ],
                  ),
                ),

                SizedBox(
                  height: FetchPixels.getPixelHeight(250),
                  width: FetchPixels.width,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Text(
                        CongratsBottomSheets[currentPage],
                        style: R.textStyle
                            .boldMontserrat()
                            .copyWith(fontSize: 26, color: R.colors.blackColor),
                        textAlign: TextAlign.center,
                      ),

                    ],
                  ),
                ),
                getVerSpace(FetchPixels.getPixelHeight(20)),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    InkWell(
                      onTap: () {
                        Get.toNamed(Routes.loginView);
                      },
                      child: Text(
                        "Skip",
                        style:
                            TextStyle(fontSize: 15, color: R.colors.blackColor),
                      ),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: List.generate(
                        3,
                        (index) => Container(
                          margin: EdgeInsets.only(right: 5),
                          height: currentPage == index
                              ? height * 0.03
                              : height * 0.015,
                          width: currentPage == index
                              ? width * 0.012
                              : width * 0.01,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            color: R.colors.blackColor,
                          ),
                        ),
                      ),
                    ),
                    InkWell(
                      onTap: () {
                        print(currentPage);
                        if (currentPage <= 1) {
                          currentPage = currentPage + 1;
                          pageController.jumpToPage(currentPage);
                          setState(() {});
                        } else {
                          Get.toNamed(Routes.loginView);
                        }
                      },
                      child: Container(
                        padding: EdgeInsets.symmetric(
                            horizontal: FetchPixels.getPixelWidth(10),
                            vertical: FetchPixels.getPixelHeight(7)),
                        // height: height * 0.05,
                        // width: width * 0.1,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: R.colors.blackColor,
                        ),
                        child: currentPage == 2
                            ? Text(
                                "Let's go",
                                style: R.textStyle.mediumMontserrat().copyWith(
                                    fontSize: 13, color: R.colors.whiteColor),
                              )
                            : Icon(
                                Icons.arrow_forward_rounded,
                                size: 18,
                                color: R.colors.whiteColor,
                              ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ));
  }
}
