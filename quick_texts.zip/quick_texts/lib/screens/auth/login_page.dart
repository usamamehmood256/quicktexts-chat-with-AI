
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import 'package:quick_texts/screens/auth/provider/auth_provider.dart';

import '../../base/resizer/fetch_pixels.dart';
import '../../base/widget_utils.dart';
import '../../resources/resources.dart';
import '../../routes/app_routes.dart';
import '../../utils/validator.dart';
import '../../widgets/my_button.dart';

class LoginView extends StatelessWidget {
  LoginView({Key? key}) : super(key: key);
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  TextEditingController emailCT = TextEditingController();
  TextEditingController passCT = TextEditingController();
  FocusNode passFN = FocusNode();

  @override
  Widget build(BuildContext context) {
    return Consumer<AuthProvider>(
      builder: (context, auth, child) {
        return Scaffold(
          body: getPaddingWidget(
            EdgeInsets.symmetric(horizontal: FetchPixels.getPixelWidth(20)),
            SingleChildScrollView(
              child: Form(
                key: formKey,
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      getVerSpace(FetchPixels.getPixelHeight(50)),
                      Align(
                        alignment: Alignment.center,
                        child: getAssetImage(R.images.logo,
                            height: FetchPixels.getPixelHeight(150),
                            width: FetchPixels.getPixelWidth(200)),
                      ),
                      getVerSpace(FetchPixels.getPixelHeight(50)),
                      Text(
                        "EMAIL",
                        style: R.textStyle.semiBoldMontserrat().copyWith(
                            fontSize: 12, color: R.colors.headingColor),
                      ),
                      getVerSpace(FetchPixels.getPixelHeight(10)),
                      TextFormField(
                          autovalidateMode: AutovalidateMode.onUserInteraction,
                          keyboardType: TextInputType.emailAddress,
                          textInputAction: TextInputAction.next,
                          style: R.textStyle.mediumMontserrat().copyWith(
                              color: R.colors.blackColor, fontSize: 14),
                          controller: emailCT,
                          cursorColor: R.colors.theme,
                          validator: (value) =>
                              FieldValidator.validateEmail(value!),
                          decoration: R.decorations.textFormFieldDecoration(
                              null, "Enter Email here...")),
                      getVerSpace(FetchPixels.getPixelHeight(20)),
                      Text(
                        "PASSWORD",
                        style: R.textStyle.semiBoldMontserrat().copyWith(
                            fontSize: 12, color: R.colors.headingColor),
                      ),
                      getVerSpace(FetchPixels.getPixelHeight(10)),
                      TextFormField(
                          autovalidateMode: AutovalidateMode.onUserInteraction,
                          keyboardType: TextInputType.visiblePassword,
                          textInputAction: TextInputAction.done,
                          obscureText: auth.passVisible,
                          validator: (value) =>
                              FieldValidator.validatePassword(value!),
                          style: R.textStyle.mediumMontserrat().copyWith(
                              color: R.colors.blackColor, fontSize: 14),
                          controller: passCT,
                          cursorColor: R.colors.theme,
                          decoration: R.decorations.textFormFieldDecoration(
                              InkWell(
                                onTap: () {
                                  auth.passVisible = !auth.passVisible;
                                  auth.update();
                                },
                                child: Icon(
                                    !auth.passVisible
                                        ? Icons.visibility_off
                                        : Icons.visibility,
                                    color: passFN.hasFocus
                                        ? R.colors.theme
                                        : R.colors.hintText),
                              ),
                              "Enter Password here...")),
                      getVerSpace(FetchPixels.getPixelHeight(10)),
                      Align(
                        alignment: Alignment.centerRight,
                        child: InkWell(
                          onTap: () {
                            Get.toNamed(Routes.forgotPassword);
                          },
                          child: Text(
                            "FORGOT PASSWORD?",
                            style: R.textStyle.semiBoldMontserrat().copyWith(
                                fontSize: 12,
                                color: R.colors.headingColor,
                                decoration: TextDecoration.underline),
                          ),
                        ),
                      ),
                      getVerSpace(FetchPixels.getPixelHeight(50)),
                      auth.isLoading == true
                          ? Center(
                              child: CircularProgressIndicator(
                                strokeWidth: 10,
                                color: R.colors.theme,
                              ),
                            )
                          : MyButton(
                              onTap: () {
                                if (formKey.currentState!.validate()) {
                                  auth.signInMethod(emailCT.text, passCT.text);
                                }
                              },
                              buttonText: "Login",
                            ),
                      getVerSpace(FetchPixels.getPixelHeight(20)),
                      Center(
                        child: Text(
                          "Or",
                          style: R.textStyle.boldMontserrat().copyWith(
                              fontSize: 13, color: R.colors.headingColor),
                        ),
                      ),

                      getVerSpace(FetchPixels.getPixelHeight(120)),
                      Align(
                        alignment: Alignment.center,
                        child: Text(
                          "Don’t have an account?",
                          style: R.textStyle.semiBoldMontserrat().copyWith(
                                fontSize: 14,
                                color: R.colors.headingColor,
                              ),
                        ),
                      ),
                      getVerSpace(FetchPixels.getPixelHeight(10)),
                      MyButton(
                        onTap: () {
                          Get.toNamed(Routes.signupView);
                        },
                        buttonText: "Sign up",
                      ),
                    ]),
              ),
            ),
          ),
        );
      },
    );
  }
}
