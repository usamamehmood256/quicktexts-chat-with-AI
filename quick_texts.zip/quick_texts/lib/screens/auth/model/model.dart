import 'package:cloud_firestore/cloud_firestore.dart';

class UserModel {
  String? name;
  String? email;
  List<dynamic>? savedMessages;
  bool? isSubscribe;
  int? freeRequestLimit;
  Timestamp? startSubscription;
  Timestamp? endSubscription;

  UserModel(
      {this.name,
      this.email,
      this.freeRequestLimit,
      this.savedMessages,
      this.isSubscribe,
      this.startSubscription,
      this.endSubscription});

  UserModel.fromJson(dynamic json) {
    name = json['name'];
    freeRequestLimit = json['freeRequestLimit'];
    email = json['email'];
    savedMessages = json['savedMessages'];
    isSubscribe = json['isSubscribe'];
    startSubscription = json['startSubscription'];
    endSubscription = json['endSubscription'];
  }

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['name'] = name;
    map['freeRequestLimit'] = freeRequestLimit;
    map['email'] = email;
    map['savedMessages'] = savedMessages;
    map['isSubscribe'] = isSubscribe;
    map['startSubscription'] = startSubscription;
    map['endSubscription'] = endSubscription;

    return map;
  }
}
