
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:provider/provider.dart';
import 'package:quick_texts/screens/auth/provider/auth_provider.dart';

import '../../base/resizer/fetch_pixels.dart';
import '../../base/widget_utils.dart';
import '../../dialogs/congrats_dialogue.dart';
import '../../resources/resources.dart';
import '../../routes/app_routes.dart';
import '../../utils/validator.dart';
import '../../widgets/my_button.dart';
import 'model/model.dart';

class SignupView extends StatelessWidget {
  SignupView({Key? key}) : super(key: key);
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  TextEditingController emailCT = TextEditingController();
  TextEditingController fullNameCT = TextEditingController();
  TextEditingController passCT = TextEditingController();
  TextEditingController confirmPassCT = TextEditingController();
  FocusNode passFN = FocusNode();
  FocusNode confirmPass = FocusNode();
  @override
  Widget build(BuildContext context) {
    return Consumer<AuthProvider>(
      builder: (context, auth, child) {
        return Scaffold(
          body: getPaddingWidget(
            EdgeInsets.symmetric(horizontal: FetchPixels.getPixelWidth(20)),
            SingleChildScrollView(
              child: Form(
                key: formKey,
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      getVerSpace(FetchPixels.getPixelHeight(50)),
                      Align(
                        alignment: Alignment.center,
                        child: getAssetImage(R.images.logo,
                            height: FetchPixels.getPixelHeight(150),
                            width: FetchPixels.getPixelWidth(200)),
                      ),
                      getVerSpace(FetchPixels.getPixelHeight(30)),
                      Text(
                        "NAME",
                        style: R.textStyle.semiBoldMontserrat().copyWith(
                            fontSize: 12, color: R.colors.headingColor),
                      ),
                      getVerSpace(FetchPixels.getPixelHeight(10)),
                      TextFormField(
                          autovalidateMode: AutovalidateMode.onUserInteraction,
                          keyboardType: TextInputType.name,
                          validator: (value) =>
                              FieldValidator.validateName(value!),
                          textInputAction: TextInputAction.next,
                          style: R.textStyle.mediumMontserrat().copyWith(
                              color: R.colors.blackColor, fontSize: 14),
                          controller: fullNameCT,
                          cursorColor: R.colors.theme,
                          decoration: R.decorations.textFormFieldDecoration(
                              null, "Enter Name here...")),
                      getVerSpace(FetchPixels.getPixelHeight(20)),
                      Text(
                        "EMAIL",
                        style: R.textStyle.semiBoldMontserrat().copyWith(
                            fontSize: 12, color: R.colors.headingColor),
                      ),
                      getVerSpace(FetchPixels.getPixelHeight(10)),
                      TextFormField(
                          autovalidateMode: AutovalidateMode.onUserInteraction,
                          keyboardType: TextInputType.emailAddress,
                          textInputAction: TextInputAction.next,
                          validator: (value) =>
                              FieldValidator.validateEmail(value!),
                          style: R.textStyle.mediumMontserrat().copyWith(
                              color: R.colors.blackColor, fontSize: 14),
                          controller: emailCT,
                          cursorColor: R.colors.theme,
                          decoration: R.decorations.textFormFieldDecoration(
                              null, "Enter Email here...")),
                      getVerSpace(FetchPixels.getPixelHeight(20)),
                      Text(
                        "PASSWORD",
                        style: R.textStyle.semiBoldMontserrat().copyWith(
                            fontSize: 12, color: R.colors.headingColor),
                      ),
                      getVerSpace(FetchPixels.getPixelHeight(10)),
                      TextFormField(

                          autovalidateMode: AutovalidateMode.onUserInteraction,
                          keyboardType: TextInputType.visiblePassword,
                          textInputAction: TextInputAction.next,
                          obscureText: auth.newPassVisible,
                          validator: (value) =>
                              FieldValidator.validatePassword(value!),
                          style: R.textStyle.mediumMontserrat().copyWith(
                              color: R.colors.blackColor, fontSize: 14),
                          controller: passCT,
                          cursorColor: R.colors.theme,
                          decoration: R.decorations.textFormFieldDecoration(
                              InkWell(
                                onTap: () {
                                  auth.newPassVisible = !auth.newPassVisible;
                                  auth.update();
                                },
                                child: Icon(
                                    !auth.newPassVisible
                                        ? Icons.visibility_off
                                        : Icons.visibility,
                                    color: passFN.hasFocus
                                        ? R.colors.theme
                                        : R.colors.hintText),
                              ),
                              "Enter Password here...")),
                      getVerSpace(FetchPixels.getPixelHeight(10)),
                      Text(
                        "CONFIRM PASSWORD",
                        style: R.textStyle.semiBoldMontserrat().copyWith(
                            fontSize: 12, color: R.colors.headingColor),
                      ),
                      getVerSpace(FetchPixels.getPixelHeight(10)),
                      TextFormField(
                          obscureText: auth.newConPassVisible,
                          autovalidateMode: AutovalidateMode.onUserInteraction,
                          keyboardType: TextInputType.visiblePassword,
                          textInputAction: TextInputAction.done,
                          validator: (value) =>
                              FieldValidator.validatePasswordMatch(
                                  value!, passCT.text),
                          style: R.textStyle.mediumMontserrat().copyWith(
                              color: R.colors.blackColor, fontSize: 14),
                          controller: confirmPassCT,
                          cursorColor: R.colors.theme,
                          decoration: R.decorations.textFormFieldDecoration(
                              InkWell(
                                onTap: () {
                                  auth.newConPassVisible =
                                      !auth.newConPassVisible;
                                  auth.update();
                                },
                                child: Icon(
                                    !auth.newConPassVisible
                                        ? Icons.visibility_off
                                        : Icons.visibility,
                                    color: confirmPass.hasFocus
                                        ? R.colors.theme
                                        : R.colors.hintText),
                              ),
                              "Enter Password again...")),
                      getVerSpace(FetchPixels.getPixelHeight(30)),
                      auth.isLoading == true
                          ? Center(
                              child: CircularProgressIndicator(
                              strokeWidth: 10,
                              color: R.colors.theme,
                            ))
                          : MyButton(
                              onTap: () async {
                                if (formKey.currentState!.validate()) {
                                  auth.startLoader();
                                  UserModel userModel = UserModel(
                                    name: fullNameCT.text,
                                    email: emailCT.text,
                                    savedMessages: [],
                                    isSubscribe: false,
                                    freeRequestLimit: 0,

                                  );
                                  await auth.registerUser(
                                      userModel, confirmPassCT.text);
                                  auth.stopLoader();
                                }
                              },
                              buttonText: "Sign up",
                            ),
                      getVerSpace(FetchPixels.getPixelHeight(30)),
                      Align(
                        alignment: Alignment.center,
                        child: Text(
                          "Already have an account?",
                          style: R.textStyle.semiBoldMontserrat().copyWith(
                                fontSize: 14,
                                color: R.colors.headingColor,
                              ),
                        ),
                      ),
                      getVerSpace(FetchPixels.getPixelHeight(10)),
                      MyButton(
                        onTap: () {
                          Get.toNamed(Routes.loginView);
                        },
                        buttonText: "Login",
                      ),
                    ]),
              ),
            ),
          ),
        );
      },
    );
  }
}
