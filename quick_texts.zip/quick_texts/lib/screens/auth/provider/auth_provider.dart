import 'dart:async';
import 'dart:convert';
import 'dart:developer';


import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:http/http.dart' as http;
import '../../../dialogs/congrats_dialogue.dart';
import '../../../resources/resources.dart';
import '../../../routes/app_routes.dart';
import '../../../services/auth_service.dart';
import '../../../utils/app_utils.dart';
import '../../../utils/fb_collection.dart';
import '../../../utils/show_message.dart';
import '../../dashboard/dashboard_view.dart';
import '../login_page.dart';
import '../model/model.dart';

class AuthProvider extends ChangeNotifier {
  /// context Page ///
  TextEditingController contextCt = TextEditingController();

  /// about Text Page ///
  TextEditingController aboutTextCT = TextEditingController();
  FocusNode customTextFN = FocusNode();

  /// Tone Text Page ///
  TextEditingController toneTextCT = TextEditingController();
  FocusNode tonCustomTextFN = FocusNode();

  UserModel userModel = UserModel();
  BaseAuth? baseAuth = Auth();

  update() {
    notifyListeners();
  }

  /// login Page ObsCure Texts ///
  bool passVisible = false;

  /// SignUp Page ObsCure texts ///
  bool newPassVisible = false;
  bool newConPassVisible = false;

  /// Dashboard PageView Indexes ///
  PageController messagePC = PageController();
  int currentPage = 0;

  /// select Message Type page ///
  int currentIndex = 0;

  /// about Message Page Indexes ///
  int aboutCurrentIndex = 0;
  List<String> aboutTexts = [
    "Birthday",
    "Thank You",
    "Love",
    "Missing You",
    "Casual Chat",
    "Custom (Premium)",
  ];

  /// Message Tone page Indexes ///
  int toneMessageIndex = 0;
  List<String> toneTexts = [
    "Funny",
    "Casual",
    "Sassy",
    "Sarcastic",
    "Cute",
    "Rude",
    "Neutral",
    "Custom ",
  ];

  /// Subscription Page ///
  int selectedSubscription = 0;

  /// google Signin Loaders ///
  bool isGoogleLoading = false;
  startGoogleLoader() {
    isGoogleLoading = true;
    notifyListeners();
  }

  stopGoogleLoader() {
    isGoogleLoading = false;
    notifyListeners();
  }

  bool isLoading = false;
  startLoader() {
    isLoading = true;
    notifyListeners();
  }

  stopLoader() {
    isLoading = false;
    notifyListeners();
  }

  Future signInMethod(String email, String password) async {
    startLoader();
    baseAuth?.signInQuery(email, password).then((Value) async {
      log("sign in response....$Value");
      if (Value.toString() == "0") {
        stopLoader();
      } else if (Value.toString() == "1") {
        ShowMessage.inSnackBar(
          "Verification Error",
          "please verify your email through link",
        );
        stopLoader();
      } else {
        await CheckSigninMethod(email: email);
      }
    });
  }

  Future<void> CheckSigninMethod({String? email, bool isSplash = false}) async {
    startLoader();
    userModel = (await getUserFromDB(email!))!;
    await updateFcm(email);
    log("user found = ${userModel?.toJson()}");
    Get.offAllNamed(Routes.dashboardView);

    // if (_userModel?.status == UserStatus.active.index) {
    //   stopLoader();
    //
    // } else {
    //   if (isSplash) {
    //     stopLoader();
    //     Get.offAll(const LoginPage());
    //   }
    //   ShowMessage.inSnackBar("Blocked", "User is blocked and cannot sign in");
    // }
  }

  Future<void> updateFcm(String docID) async {
    var fcm = await FBCollections.users
        .doc(docID)
        .update({"fcm_id": AppUtils.myFcmToken});

    return fcm;
  }

  Future<void> getCurrentUser() async {
    var user = await baseAuth?.CurrentUserQuery();
    if (user != null) {
      var userData = await getUserFromDB(user.email!);
      if (userData != null) {
        CheckSigninMethod(email: user.email, isSplash: true);
      } else {
        await baseAuth!.signOutQuery();
        await Get.offAll(LoginView());
      }
    } else {
      await baseAuth!.signOutQuery();
      await Get.toNamed(Routes.landingPage);
    }
  }

  Future<void> registerUser(UserModel userModel, String password) async {
    startLoader();
    DocumentSnapshot userDocument =
        await FBCollections.users.doc(userModel.email).get();

    if (userDocument.exists) {
      stopLoader();
      log("user exist");
      ShowMessage.inSnackBar("Error", "User already exists");
    } else {
      log("user does not exist");
      log("email:${userModel.email!} password $password ");
      baseAuth
          ?.createUserWithEmailAndPassword(userModel.email!, password)
          .then((value) async {
        log("create user returned value $value");

        if (value != "0" && value != "1") {
          await FBCollections.users
              .doc(userModel.email)
              .set(userModel.toJson())
              .then((value) async {
            userModel = (await getUserFromDB(userModel.email!))!;
            // stopLoader();
            Timer(const Duration(seconds: 2), () {
              Get.dialog(CongratsDialogue(
                text:
                    "We Have Sent You a Verification Link On Your Email\nPlease Verify!",
                image: R.images.logo,
              ));
            });
          });
        } else {
          stopLoader();
        }
      });
    }
  }

  void changePassword(
      {required String newPassword, required String oldPassword}) async {
    startLoader();
    try {
      startLoader();
      User? user = FirebaseAuth.instance.currentUser;
      var authResult = await user!
          .reauthenticateWithCredential(
        EmailAuthProvider.credential(
          email: user.email!,
          password: oldPassword,
        ),
      )
          .catchError((error) {
        stopLoader();
        var er = error.toString();
        print("error:$er");
        if (er.contains("wrong-password")) {
          ShowMessage.toast("Wrong old Password");
        } else {
          ShowMessage.toast(er);
        }
      });
      authResult.user!.updatePassword(newPassword).then((value) {
        stopLoader();
        Get.dialog(CongratsDialogue(
          image: R.images.logo,
          text: "Your Password is Updated\nPlease Login Again",
        ));
      });
    } catch (e) {
      stopLoader();
      ShowMessage.toast(e.toString());
      print(e.toString());
    }
  }

  Future<void> signOutQuery() async {
    await baseAuth?.signOutQuery();
    Get.toNamed(Routes.loginView);
  }

  Future<void> sendResetPassEmail(String email) async {
    startLoader();
    FirebaseAuth.instance.sendPasswordResetEmail(email: '$email').then((value) {
      startLoader();
      // Get.to(confirmSendEmail());
      Get.dialog(CongratsDialogue(
        image: R.images.logo,
        text:
            "The Password Reset Has Been Sent on Your Provided Email\nPlease Check Your Email!",
      ));
      stopLoader();
    }).catchError((e) {
      String error = e.toString();
      print(error);

      if (error.contains('user-not-found')) {
        ShowMessage.toast('Email not registered');
      } else {
        print(e.toString());

        isLoading = false;
        // ShowMessage.toast(e.toString());
      }
      stopLoader();
    });
  }

  Future<UserModel?> getUserFromDB(String docId) async {
    startLoader();
    DocumentSnapshot doc = await FBCollections.users.doc(docId).get();
    stopLoader();
    if (!doc.exists) {
      return null;
    }
    UserModel user = UserModel.fromJson(doc.data() as Map<String, dynamic>);
    return user;

  }




// Function to make the API request
  Future<String> generateResponse(String prompt) async {
    final apiKey = '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';
    final url = 'https://api.openai.com/v1/engines/davinci-codex/completions';

    final response = await http.post(
      Uri.parse(url),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $apiKey',
      },
      body: '{"prompt": "$prompt", "max_tokens": 100}',
    );

    if (response.statusCode == 200) {
      final jsonResponse = json.decode(response.body);
      final generatedText = jsonResponse['choices'][0]['text'].toString();
      return generatedText;
    } else {
      throw Exception('Failed to generate response: ${response.statusCode}');
    }
  }

}
