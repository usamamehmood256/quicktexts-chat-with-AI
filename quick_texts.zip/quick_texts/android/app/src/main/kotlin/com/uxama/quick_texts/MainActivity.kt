package com.uxama.quick_texts

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
